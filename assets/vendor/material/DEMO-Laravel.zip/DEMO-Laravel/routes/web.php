<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AboutController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\TeamController;
use App\Http\Controllers\BookingController;
use App\Http\Controllers\TestimonialController;
use App\Http\Controllers\AdminController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*
Route::get('/', function () {
    return view('welcome');
});
*/

Route::get('/',[UserController::class,'user']);

Route::get('/about',[AboutController::class,'about']);

Route::get('/service',[ServiceController::class,'service']);

Route::get('/menu',[MenuController::class,'menu']);

Route::get('/booking',[BookingController::class,'booking']);
Route::post('/booking',[BookingController::class,'booked']); //get data from form

Route::get('/team',[TeamController::class,'team']);

Route::get('/testimonial',[TestimonialController::class,'testimonial']);

Route::get('/contact',[ContactController::class,'contact']);
Route::post('/contact',[ContactController::class,'feedback']); //get data from contact

//admin section
Route::get('/admin',[AdminController::class,'view']);
Route::get('/admin/delete/{id}',[AdminController::class,'delete'])->name('customer.delete'); //delete data

//book
Route::get('/form',[AdminController::class,'Booking']);
Route::post('/form',[AdminController::class,'Booked']); //get data from form

//update
Route::get('/admin/edit/{id}',[AdminController::class,'edit'])->name('customer.edit');
Route::post('/admin/update/{id}',[AdminController::class,'update'])->name('customer.update');


