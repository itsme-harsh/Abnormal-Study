<html>
    <head>
        <title>intro</title>
    </head>
    <body>
    <h1>
      <a href="/"><b>home</b></a>
      <a href="/user"><b>file</b></a>
      <a href="/intro"><b>intro</b></a>
      <a href="/para"><b>para</b></a></h1>

      
      <h2>Mahatma Gandhi Mohandas Karamchand Gandhi was an Indian lawyer, anti-colonial nationalist and political ethicist who employed nonviolent resistance to lead the successful ...
Movemen
      </h2>
    
            </body>
</html><?php /**PATH C:\xampp\htdocs\DEMO-Laravel\resources\views/para.blade.php ENDPATH**/ ?>