<html>
    <head>
        <title>User</title>
</head>
    <body>
    <h1>
      <a href="/"><b>home</b></a>
      <a href="/user"><b>file</b></a>
      <a href="/intro"><b>intro</b></a>
      <a href="/para"><b>para</b></a></h1>


      
        <h1>UESR PAGE</h1>


       
</body>
</html><?php /**PATH C:\xampp\htdocs\DEMO-Laravel\resources\views/User.blade.php ENDPATH**/ ?>