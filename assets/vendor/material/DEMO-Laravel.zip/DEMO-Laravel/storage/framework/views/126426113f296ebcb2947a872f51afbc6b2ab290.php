<html>
    <head>
        <title>User</title>
</head>
    <body>
        <h1>UESR PAGE</h1>
</body>
</html><?php /**PATH C:\xampp\htdocs\DEMO-Laravel\resources\views/user.blade.php ENDPATH**/ ?>