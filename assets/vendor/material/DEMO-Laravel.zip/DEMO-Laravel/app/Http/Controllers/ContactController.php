<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ContactController extends Controller
{
    function contact()
    {
        return view("contact");
    }
    function feedback(Request $request)
    {
        echo "<pre>"; //for line by line output
        print_r($request->all()); // will print form data as array
    }
}
