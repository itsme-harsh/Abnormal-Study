<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;

class AdminController extends Controller
{
    //display
    public function admin()
    {
        return view("admin");
        
    }

    //display data
    public function view(Request $request){

        $search = $request['search'] ?? "";
        if($search != ""){
            $customer = customer::where('name','LIKE',"$search%")->orwhere('request','LIKE',"$search%")->orwhere('email','LIKE',"$search%")->orwhere('seatbook','LIKE',"$search%")->get();
        }else{
            $customer = customer::all();
        }
        $data = compact('customer');
        return view('admin')->with($data);
    }

    // form
    public function Booking()
    {
        $url = url('form');
        $customer = new customer();
        $title = "Book A Table Online";
        $data = compact('url','title','customer');
        return view("form")->with($data);
    }

    //insert data
    public function Booked(Request $request)
    {
       $request->validate(
            [
                'name' => 'required',
                'email'=>'required|email',
                'datetime'=>'required',
                'seatbook'=>'required',
                'message'=>'required'
            ]
       );
       $customer = new customer;
       $customer->name =$request['name'];
       $customer->email =  $request['email'];
       $customer->date =$request['datetime'];
       $customer->seatbook = $request['seatbook'];
       $customer->request =$request['message'];
       $customer->save();
       return redirect('admin');
    }

    //delete 
    public function delete($id){
        $customer = customer::find($id);
        if(!is_null($customer)){
            $customer->delete();
        }
        return redirect('admin');
    }

    //get value for edit
    public function edit($id){
        $customer = customer::find($id);
        $title = "Update data";
        $url = url('/admin/update')."/".$id;
        $data = compact('customer','url','title');
        return view('form')->with($data);
    }

    public function update($id,Request $request){
        $request->validate(
            [
                'name' => 'required',
                'email'=>'required|email',
                'datetime'=>'required',
                'seatbook'=>'required',
                'message'=>'required'
            ]
            );
       $customer = customer::find($id);
       $customer->name =$request['name'];
       $customer->email =  $request['email'];
       $customer->date =$request['datetime'];
       $customer->seatbook = $request['seatbook'];
       $customer->request =$request['message'];
       $customer->save();
       return redirect('admin');
    }

}
