<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;

class BookingController extends Controller
{
    function booking()
    {
        return view("booking");
    }

    public function booked(Request $request)
    {
       $customer = new customer;
       $customer->name =$request['name'];
       $customer->email =  $request['email'];
       $customer->date =$request['datetime'];
       $customer->seatbook = $request['select1'];
       $customer->request =$request['message'];
       $customer->save();
       return redirect()->back();
    }
}   
